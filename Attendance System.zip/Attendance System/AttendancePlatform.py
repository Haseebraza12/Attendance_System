from PyQt6.QtGui import QPixmap
from PyQt6.QtWidgets import (
    QApplication,
    QMainWindow,
    QVBoxLayout,
    QTableWidget,
    QTableWidgetItem,
    QPushButton,
    QAbstractItemView,
    QHBoxLayout,
    QDialog,
    QCalendarWidget,
    QDialogButtonBox,
    QWidget,
    QLabel,
    QInputDialog,
    QDockWidget
)
from PyQt6.QtCore import Qt, QFile, QDate, QPropertyAnimation, QRect, QEasingCurve
import sys
import csv
import datetime as dt
import os

class AttendancePlatform(QMainWindow):
    def __init__(self):
        super().__init__()

        self.student_data = []
        self.load_student_data_from_csv()
        self.current_date = dt.date.today()

        self.init_ui()

    def init_ui(self):
        # Create the main window layout
        main_widget = QWidget()
        main_layout = QVBoxLayout(main_widget)
        self.setCentralWidget(main_widget)

        self.setWindowTitle(f"Attendance System - {self.current_date}")

        # Create student table
        self.student_table = QTableWidget()
        self.student_table.setColumnCount(4)
        self.student_table.setHorizontalHeaderLabels(['Student Number', 'Name', 'Programme', 'Attendance'])
        self.student_table.setSelectionBehavior(QAbstractItemView.SelectionBehavior.SelectRows)
        self.student_table.setSelectionMode(QAbstractItemView.SelectionMode.SingleSelection)
        self.student_table.itemSelectionChanged.connect(self.display_student_details)

        main_layout.addWidget(self.student_table)

        # Create buttons
        button_layout = QHBoxLayout()

        self.set_date_button = QPushButton("Set Date")
        self.set_date_button.clicked.connect(self.set_date)
        self.animate_button(self.set_date_button)
        button_layout.addWidget(self.set_date_button)

        self.mark_all_present_button = QPushButton("Mark All Present")
        self.mark_all_present_button.clicked.connect(self.mark_all_present)
        self.animate_button(self.mark_all_present_button)
        button_layout.addWidget(self.mark_all_present_button)

        self.mark_all_absent_button = QPushButton("Mark All Absent")
        self.mark_all_absent_button.clicked.connect(self.mark_all_absent)
        self.animate_button(self.mark_all_absent_button)
        button_layout.addWidget(self.mark_all_absent_button)

        self.reset_attendance_button = QPushButton("Reset Attendance")
        self.reset_attendance_button.clicked.connect(self.reset_attendance)
        self.animate_button(self.reset_attendance_button)
        button_layout.addWidget(self.reset_attendance_button)

        self.export_attendance_button = QPushButton("Export Attendance")
        self.export_attendance_button.clicked.connect(self.export_attendance)
        self.animate_button(self.export_attendance_button)
        button_layout.addWidget(self.export_attendance_button)

        main_layout.addLayout(button_layout)

        # Create the dock widget
        self.dock = QDockWidget("Student Details", self)
        self.addDockWidget(Qt.DockWidgetArea.RightDockWidgetArea, self.dock)
        self.dock_widget = QWidget()
        self.dock_layout = QVBoxLayout(self.dock_widget)
        self.dock.setWidget(self.dock_widget)

        self.student_detail_label = QLabel()
        self.student_photo_label = QLabel()
        self.dock_layout.addWidget(self.student_detail_label)
        self.dock_layout.addWidget(self.student_photo_label)

        self.edit_button = QPushButton("Edit")
        self.edit_button.clicked.connect(self.edit_student_details)
        self.animate_button(self.edit_button)
        self.dock_layout.addWidget(self.edit_button)

        self.populate_table()

        # Set gradient background
        self.set_gradient_background()

    def set_gradient_background(self):
        self.setStyleSheet("""
            QMainWindow {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:1, stop:0 #e0c9f8, stop:1 #ffffff);
            }
            QPushButton {
                background-color: #d8aaff;
                border: none;
                padding: 10px;
                color: white;
                border-radius: 5px;
            }
            QPushButton:hover {
                background-color: #c09bff;
            }
            QLabel {
                font-size: 14px;
                color: #333;
            }
        """)

    def animate_button(self, button):
        animation = QPropertyAnimation(button, b"geometry")
        animation.setDuration(300)
        animation.setStartValue(QRect(button.geometry()))
        animation.setEndValue(QRect(button.geometry().x(), button.geometry().y() - 10, button.geometry().width(), button.geometry().height()))
        animation.setEasingCurve(QEasingCurve.Type.InOutQuad)
        animation.start()

    def populate_table(self):
        self.student_table.setRowCount(0)
        for student in self.student_data:
            row_position = self.student_table.rowCount()
            self.student_table.insertRow(row_position)
            self.student_table.setItem(row_position, 0, QTableWidgetItem(student[0]))
            self.student_table.setItem(row_position, 1, QTableWidgetItem(student[1]))
            self.student_table.setItem(row_position, 2, QTableWidgetItem(student[2]))
            self.student_table.setItem(row_position, 3, QTableWidgetItem(""))

    def set_date(self):
        dialog = QDialog(self)
        dialog.setWindowTitle("Select Date")
        layout = QVBoxLayout(dialog)
        calendar = QCalendarWidget(dialog)
        calendar.setSelectedDate(QDate(self.current_date.year, self.current_date.month, self.current_date.day))
        layout.addWidget(calendar)
        buttons = QDialogButtonBox(QDialogButtonBox.StandardButton.Ok | QDialogButtonBox.StandardButton.Cancel, dialog)
        layout.addWidget(buttons)
        buttons.accepted.connect(lambda: self.update_date(calendar.selectedDate(), dialog))
        buttons.rejected.connect(dialog.reject)
        dialog.exec()

    def update_date(self, date, dialog):
        self.current_date = dt.date(date.year(), date.month(), date.day())
        self.setWindowTitle(f"Your Name - Your Student Number - {self.current_date}")
        dialog.accept()

    def mark_all_present(self):
        self.animate_button(self.mark_all_present_button)
        for row in range(self.student_table.rowCount()):
            self.student_table.setItem(row, 3, QTableWidgetItem("Present"))

    def mark_all_absent(self):
        self.animate_button(self.mark_all_absent_button)
        for row in range(self.student_table.rowCount()):
            self.student_table.setItem(row, 3, QTableWidgetItem("Absent"))

    def reset_attendance(self):
        self.animate_button(self.reset_attendance_button)
        for row in range(self.student_table.rowCount()):
            self.student_table.setItem(row, 3, QTableWidgetItem(""))

    def export_attendance(self):
        self.animate_button(self.export_attendance_button)
        file_name = f"{self.current_date}.txt"
        with open(file_name, 'w') as file:
            for row in range(self.student_table.rowCount()):
                student_number = self.student_table.item(row, 0).text()
                name = self.student_table.item(row, 1).text()
                programme = self.student_table.item(row, 2).text()
                attendance = self.student_table.item(row, 3).text()
                file.write(f"{student_number}, {name}, {programme}, {attendance}\n")

    def load_student_data_from_csv(self):
        csv_file_path = "C:\\Users\\Haseeb Ur Rehman\\Desktop\\Project1\\students.csv"
        if os.path.exists(csv_file_path):
            with open(csv_file_path, 'r') as file:
                reader = csv.reader(file)
                self.student_data = list(reader)

    def display_student_details(self):
        selected_row = self.student_table.currentRow()
        if selected_row != -1:
            student_number = self.student_table.item(selected_row, 0).text()
            name = self.student_table.item(selected_row, 1).text()
            programme = self.student_table.item(selected_row, 2).text()
            self.student_detail_label.setText(f"Student Number: {student_number}\nName: {name}\nProgramme: {programme}")

            # Load student photo
            photo_path = f"C:\\Users\\Haseeb Ur Rehman\\Desktop\\Project1\\images\\{student_number}.png"
            pixmap = QPixmap(photo_path)
            if pixmap.isNull():
                self.student_photo_label.setText("No photo available")
            else:
                self.student_photo_label.setPixmap(pixmap)
                self.student_photo_label.setScaledContents(True)
                self.student_photo_label.setFixedSize(150, 150)

    def edit_student_details(self):
        selected_row = self.student_table.currentRow()
        if selected_row != -1:
            name, ok = QInputDialog.getText(self, "Edit Name", "Name:", text=self.student_table.item(selected_row, 1).text())
            if ok:
                self.student_table.setItem(selected_row, 1, QTableWidgetItem(name))
            programme, ok = QInputDialog.getText(self, "Edit Programme", "Programme:", text=self.student_table.item(selected_row, 2).text())
            if ok:
                self.student_table.setItem(selected_row, 2, QTableWidgetItem(programme))
            self.update_student_data_csv()

    def update_student_data_csv(self):
        csv_file_path = "C:\\Users\\Haseeb Ur Rehman\\Desktop\\Project1\\students.csv"
        with open(csv_file_path, 'w', newline='') as file:
            writer = csv.writer(file)
            for row in range(self.student_table.rowCount()):
                student_number = self.student_table.item(row, 0).text()
                name = self.student_table.item(row, 1).text()
                programme = self.student_table.item(row, 2).text()
                writer.writerow([student_number, name, programme])


if __name__ == '__main__':
    app = QApplication(sys.argv)
    window = AttendancePlatform()
    window.show()
    sys.exit(app.exec())
